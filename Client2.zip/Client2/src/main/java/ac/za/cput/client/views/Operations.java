
package ac.za.cput.client.views;



import java.awt.BorderLayout;
import java.awt.Container;

import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;

/**
 *
 * @author LaSavage
 */

    @SuppressWarnings("serial")
 public class Operations extends JFrame 
{
	// Create Tabbed Pane
	JTabbedPane TabbedPane = new JTabbedPane();
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Operations(String title) throws  IOException 
	{
		super();
		// Set Size and Position
		setBounds(100, 100, 450, 250);
		Container ControlHost = getContentPane();
		ControlHost.setLayout(new BorderLayout());
		
		
		// Create the Panels (Acts as Tab Sheets)
		AddBook addBook = new AddBook();
		AddLearner addLearner = new AddLearner();
		Borrow borrow = new Borrow();
                ReturnBook returnBook = new ReturnBook();
                OverdueBooks overdue =  new OverdueBooks();
                Fine fine =  new Fine();
		
		// Add Panels as Tab
		TabbedPane.addTab("Add A Book", addBook);
		TabbedPane.addTab("Add A Learner", addLearner) ;
		TabbedPane.addTab("Borrow", borrow);
                TabbedPane.addTab("Return A Book", returnBook);
                TabbedPane.addTab("Overdue Books", overdue);
                TabbedPane.addTab("Learner & Penalty", fine);
               
                
                
		TabbedPane.setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);
		
		ControlHost.add(TabbedPane);
	}
}