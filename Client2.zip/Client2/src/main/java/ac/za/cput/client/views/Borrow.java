/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.views;


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

public class Borrow extends JPanel implements ActionListener{
    private JLabel lblPicture,  lblIsbnReq,  lblIsbn, lblMemberID,lblMemberIDReq, lblPeriod,lblPeriodReq, lblIssue, lblIssueReq;
    private JTextField txtIsbn, txtMemberID, txtPeriod , txtIssue;
    private JButton btnBorrow;
	public Borrow() throws IOException 
	{
		super();
		setLayout(null);
		addControls();
	}
	
	private void addControls() throws IOException 
	{
		BufferedImage image =  ImageIO.read(new File("Borrow.jpg"));
                 lblPicture =  new JLabel(new ImageIcon(image));
                
              
		lblIsbn = new JLabel("ISBN: ");
                lblIsbnReq  = new JLabel();
                
		lblMemberID = new JLabel("MemberID: ");
                lblMemberIDReq =  new JLabel();
                
		lblPeriod= new JLabel("Period (Days): ");
                lblPeriodReq =  new JLabel();
                
               lblIssue = new JLabel("Issued Date(DD-MM-YYYY):");
                lblIssueReq=  new JLabel();
                
                //bounds
                lblPicture.setBounds(100,20,130,130);
            
		lblIsbn.setBounds(10,180,100,25);
		lblMemberID.setBounds(10,220,100,25);
		lblPeriod.setBounds(10,260,100,25);
                lblIssue.setBounds(10,300,170,25);
               
                add(lblPicture);
		add(lblIsbn);
                add(lblIsbnReq);
		add(lblMemberID);
                add(lblMemberIDReq);
		add(lblPeriod);
                add(lblPeriodReq);
                add(lblIssue);
                add(lblIssueReq);
               
                
                
		
		//5.2 Set the Text Boxes
		txtIsbn = new JTextField();
		txtMemberID = new JTextField();
		txtPeriod = new JTextField();
                txtIssue= new JTextField();
                
                //bounds
		txtIsbn.setBounds(250,180,200,25);
		txtMemberID.setBounds(250,220,200,25);
		txtPeriod.setBounds(250,260,200,25);
                txtIssue.setBounds(250,300,200,25);
                
                
		add(txtIsbn);
		add(txtMemberID);
		add(txtPeriod);
                add(txtIssue);
                
                 btnBorrow = new JButton("Insert the information");
                btnBorrow.setBounds(250, 340, 200, 25);
                btnBorrow.addActionListener(this);
                add(btnBorrow);
                
                //empty
		
	}
        
        
    private void isIsbnEmpty() {
        if (txtIsbn.getText().isBlank()) {
            lblIsbnReq.setBounds(450, 180, 200, 25);
            lblIsbnReq.setText("*Book ISBN required!");
            lblIsbnReq.setForeground(Color.red);
            txtIsbn.requestFocus();
        } else {
            lblIsbnReq.setText("");
        }
    }
 private void istxtMemberIDEmpty(){
     if(txtMemberID.getText().isBlank()){
           lblMemberIDReq.setBounds(450,220,200,25);
         
         lblMemberIDReq.setText("*Member id required!");
         lblMemberIDReq.setForeground(Color.red);    
         txtMemberID.requestFocus();
     }
     else{
         lblMemberIDReq.setText("");
     }
 }
 
     private void istxtReturnEmpty(){
     if (txtPeriod.getText().isBlank()){
          lblPeriodReq.setBounds(450, 260, 200, 25);
         lblPeriodReq.setText("*Days required!");
         lblPeriodReq.setForeground(Color.red);
        
         txtPeriod.requestFocus();
     }
     else {
         lblPeriodReq.setText("");
     }
     }
    private void istxtIssueEmpty(){
     if (txtIssue.getText().isBlank()){
          lblIssueReq.setBounds(450, 300, 200, 25);
         lblIssueReq.setText("*Issued  date required!");
         lblIssueReq.setForeground(Color.red);
        
         txtIssue.requestFocus();
     }
     else {
         lblIssueReq.setText("");
     }
     
}


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnBorrow){
            istxtMemberIDEmpty();
            istxtReturnEmpty();
             istxtIssueEmpty();
              isIsbnEmpty();
            
        }
    }
 
}

