/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;


public class OverdueBooks extends JPanel implements ActionListener
        
{
    
    JLabel lblPicture;
   JButton btnOverdue;
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public OverdueBooks() throws IOException  
  {
    // Set Size and Position
setLayout(null);
   
BufferedImage image =  ImageIO.read(new File("Overdue.jpg"));
lblPicture = new JLabel(new ImageIcon(image));
lblPicture.setBounds(270, 20, 150, 100);
add(lblPicture);

    
    // Specify the Column Names in an Array
    String headingColumns[] = 
    {
        "ISBN",
        "Member ID",
        "Issued Date"
    };
    
    // Data for the Rows of the Table.
  
    String[][] overdueBooks = 
      {
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},
                  {null, null, null},};
    
    // Create JTable and add it to Frame
    
  JTable table = new JTable(overdueBooks, headingColumns);


    
    //Show Resize Entire Table, Column shifting, column 
	//Resizing and Cell Editing
    //Shift Click or Click & Drag
    // Apply scrolling support
    JScrollPane scPaneTable = new JScrollPane(table);
    scPaneTable.setBounds(100, 120, 500, 200);
    add(scPaneTable);
    
 btnOverdue = new JButton("Show Overdue Books");
    btnOverdue.setBounds(400,330 , 200, 25);
btnOverdue.addActionListener(this);
    add(btnOverdue);
   
  
    
  }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()== btnOverdue){
             JOptionPane.showMessageDialog(null, "Testing");
        }
    }
  
}

