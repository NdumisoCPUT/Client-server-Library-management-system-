/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.views;

/**
 *
 * @author LaSavage
 */

 
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;

public class ProgressBar extends JFrame implements ActionListener  {
    
 	int i=0, num=0;
	JLabel lblLoading, lblPicture, lblHeading ;
	JFrame frame;
        JPanel panel, picturePanel;
	JProgressBar progressBar;
        JButton btnCancel;
	
	public ProgressBar() throws IOException{ 
            frame = new JFrame();
            panel = new JPanel();
            frame = new JFrame("ProgressBar");
		frame.setSize(800, 440);
                frame.setLocationRelativeTo(null);
                frame.setResizable(false);
		frame.setLayout(null);
              
		/*frame.add(panel);
                panel.setLayout(null);
           */
           picturePanel =  new JPanel();
           
		BufferedImage image =  ImageIO.read(new File("Icon.png"));
                lblPicture = new JLabel(new ImageIcon(image));  
                lblPicture.setBounds(300, 25, 150, 150);
                frame.add(lblPicture);
                
             lblHeading =  new JLabel("St Cyprains Library Management System");
               lblHeading.setBounds(150, 165,750,35 );
               lblHeading.setFont(new Font("SERIF", Font.BOLD, 30));
               frame.add(lblHeading);
               
              lblLoading =  new JLabel("Loading...");
		lblLoading.setBounds(200, 230, 80,20);
               frame.add(lblLoading);
               
               btnCancel =  new JButton("Cancel");
               btnCancel.setBounds(660, 375, 123, 25);
               btnCancel.addActionListener(this);
              frame.add(btnCancel);
             
            /* picturePanel.add(lblPicture);
             panel.add(picturePanel);*/
               
               
		
		progressBar = new JProgressBar(0,2000);
		progressBar.setBounds(200,250,350,30);
		progressBar.setValue(0);
                progressBar.setForeground(Color.BLUE);
		progressBar.setStringPainted(true);
		
		frame.add(progressBar);
                frame.setVisible(true);
	}
     
     private void operationsIterate() throws IOException{
           Operations ops =  new Operations("Operations"); 
           ops.setLocationRelativeTo(null);
           ops.setResizable(false);
           ops.setSize(800, 440);
           ops.setVisible(true);
        }
	   
	public void iterate() throws IOException {
        
		while(i<=2000) {
                   
			progressBar.setValue(i);
			i=i+20;
                        lblLoading.setForeground(Color.red);
			try {Thread.sleep(150);}
                        
                        catch(Exception e) {
                        e.getMessage();
                        }
                }
               
                 operationsIterate();
                frame.dispose();
                
              
                
              
	}
        
    private void progressBarCancel() throws IOException {
            LoginGUI login =  new LoginGUI();
               frame.dispose();
               login.setGUI();
            
      } 
        
    @Override
    public void actionPerformed(ActionEvent e) {
       if (e.getSource()== btnCancel){
           try {
             
             progressBarCancel();
           } catch (IOException ex) {
               ex.getMessage();
           }
       }
    }
	

}