/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.views;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.*;
public class ReturnBook extends JPanel implements ActionListener{
    
private JLabel lblPicture, lblIsbn,lblIsbnReq, lblMemberID, lblMemberIDReq, lblReturn, lblReturnReq;
private JTextField txtIsbn, txtMemberID, txtReturn;
private JButton btnReturn;


public ReturnBook() throws IOException 
	{
		super();
		setLayout(null);
		addControls();
               
                     
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void addControls() throws IOException 
	{
       
             lblIsbn = new JLabel("ISBN:");
            lblIsbnReq =  new JLabel();
            
            lblMemberID = new JLabel("MemberID: ");
            lblMemberIDReq = new JLabel();
            
            lblReturn=  new JLabel("Return Date (DD-MM-YYYY): ");
            lblReturnReq =  new JLabel();
          
            
            
            
            
		
		// Set Size and Position
		
                BufferedImage image =  ImageIO.read(new File("Return.png"));
                lblPicture = new JLabel(new ImageIcon(image));
                
                //labels
                 lblPicture.setBounds(200,20,130,130);
             
                lblIsbn.setBounds(50,180,150,25);
		lblMemberID.setBounds(50,220,90,25);
		
		lblReturn.setBounds(50,260,170,25);
               
		//Add Controls
		add(lblPicture);
		add(lblIsbn);
		add(lblMemberID);
		
                add(lblReturn); 
                add( lblIsbnReq);
                 add( lblMemberIDReq);
              
                add( lblReturnReq);
               
                
                 txtIsbn =  new JTextField();
                  txtMemberID =  new JTextField();
                  txtReturn =  new JTextField();
                    
                    txtIsbn.setBounds(250, 180, 200, 25);
                 txtMemberID.setBounds(250,220,200,25);
                
                txtReturn.setBounds(250, 260, 200, 25);
                
                add(txtIsbn);
                add(txtMemberID);
                add(txtReturn);
                
                
                btnReturn = new JButton("Insert information");
                btnReturn.setBounds(250, 300, 200, 25);
                btnReturn.addActionListener(this);
                add(btnReturn);
    }

    private void isIsbnEmpty() {
        if (txtIsbn.getText().isBlank()) {
            lblIsbnReq.setBounds(450, 180, 200, 25);
            lblIsbnReq.setText("*Book ISBN required!");
            lblIsbnReq.setForeground(Color.red);
            txtIsbn.requestFocus();
        } else {
            lblIsbnReq.setText("");
        }
    }
 private void istxtMemberIDEmpty(){
     if(txtMemberID.getText().isBlank()){
           lblMemberIDReq.setBounds(450,220,200,25);
         
         lblMemberIDReq.setText("*Member id required!");
         lblMemberIDReq.setForeground(Color.red);    
         txtMemberID.requestFocus();
     }
     else{
         lblMemberIDReq.setText("");
     }
 }
 
     private void istxtReturnEmpty(){
     if (txtReturn.getText().isBlank()){
          lblReturnReq.setBounds(450, 260, 200, 25);
         lblReturnReq.setText("*Return date required!");
         lblReturnReq.setForeground(Color.red);
        
         txtReturn.requestFocus();
     }
     else {
         lblReturnReq.setText("");
     }
     
}



    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnReturn){
             isIsbnEmpty();
            istxtMemberIDEmpty();
            istxtReturnEmpty();
           
             
            
        }
    }
    
}

