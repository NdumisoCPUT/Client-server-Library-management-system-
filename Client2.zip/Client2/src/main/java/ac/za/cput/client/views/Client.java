
package ac.za.cput.client.views;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class Client {
   private Socket socket = null;
   private DataOutputStream dos =  null;
   private DataInputStream dis = null;
   
   
   public void communicate(){
       try{
       socket = new Socket("localHost", 5000);
       System.out.println("connection established");
       
       dos = new DataOutputStream(socket.getOutputStream());
       dis =  new DataInputStream(socket.getInputStream());
       
       
       } catch (Exception comm) {
           
       }
   }
}
