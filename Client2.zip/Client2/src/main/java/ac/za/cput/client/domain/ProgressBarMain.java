
package ac.za.cput.client.domain;

import ac.za.cput.client.views.ProgressBar;
import java.io.IOException;


public class ProgressBarMain {
      
    public static void main(String[] args) throws IOException {
        new ProgressBar().iterate();
       
    }
}
