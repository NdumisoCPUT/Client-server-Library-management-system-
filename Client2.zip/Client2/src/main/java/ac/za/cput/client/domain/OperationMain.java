/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.domain;

import ac.za.cput.client.views.Operations;
import java.awt.HeadlessException;
import java.io.IOException;

/**
 *
 * @author LaSavage
 */
public class OperationMain {
      public static void main(String[] args) throws IOException 
	{
		
		Operations frame = new Operations("Operations");
                frame.setLocationRelativeTo(null);
               frame.setResizable(false);
                frame.setSize(800, 440);
		frame.setVisible(true);
	}


}
