/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.domain;

/**
 *
 * @author LaSavage
 */
import ac.za.cput.client.views.LoginGUI;
import java.io.IOException;

public class LoginMain{
    public static void main(String[] args) throws IOException {
        new LoginGUI().setGUI();
    }
}

