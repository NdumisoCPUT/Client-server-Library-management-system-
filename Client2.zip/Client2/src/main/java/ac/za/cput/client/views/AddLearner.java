/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.views;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

public class AddLearner extends JPanel  implements ActionListener {
    private JLabel lblPicture, lblLearnerInfo, lblMemberID, lblMemberIDReq, lblInitials,lblInitialsReq, lblGradeReq,lblGrade;
    private JTextField txtMemberID, txtInitials, txtGrade;
    private JButton btnAddLearner;
    
	//Constructor
	public AddLearner() throws IOException 
	{
		super();
		setLayout(null);
		addControls();
                     
	}
	
	//@SuppressWarnings({ "unchecked", "rawtypes" })
	private void addControls() throws IOException 
	{
            lblLearnerInfo = new JLabel("Learner Information");
            
            lblMemberID = new JLabel("MemberID: ");
            lblMemberIDReq = new JLabel();
            
            lblInitials = new JLabel("Initials and Surname: ");
            lblInitialsReq =  new JLabel();
            
            lblGrade =  new JLabel("Grade: ");
            lblGradeReq =  new JLabel();
          
            
            
            
            
		
		//Set Size and Position
		
                BufferedImage image =  ImageIO.read(new File("learner.jpg"));
                lblPicture = new JLabel(new ImageIcon(image));
                
                //labels
                 lblPicture.setBounds(50,20,130,130);
                lblLearnerInfo.setBounds(250,130,150,25);
                
		lblMemberID.setBounds(50,180,90,25);
		lblInitials.setBounds(50,220,150,25);
		lblGrade.setBounds(50,260,80,25);
               
		//Add Controls
		add(lblPicture);
		add(lblLearnerInfo);
		add(lblMemberID);
		add(lblInitials);
                add(lblGrade);
                 add( lblMemberIDReq);
               add( lblInitialsReq);
                add( lblGradeReq);
               
                
                
                  txtMemberID =  new JTextField();
                  txtInitials =  new JTextField();
                  txtGrade =  new JTextField();
                    
                    
                 txtMemberID.setBounds(250,180,200,25);
                txtInitials.setBounds(250, 220, 200, 25);
                txtGrade.setBounds(250, 260, 200, 25);
                
               
                add(txtMemberID);
                add(txtInitials);
                add(txtGrade);
                
                
                btnAddLearner = new JButton("Insert information");
                btnAddLearner.setBounds(250, 300, 200, 25);
                btnAddLearner.addActionListener(this);
                add(btnAddLearner);
	}
        
 private void istxtMemberIDEmpty(){
     if(txtMemberID.getText().isEmpty()){
           lblMemberIDReq.setBounds(458,180,200,25);
         
         lblMemberIDReq.setText("*Member id required!");
         lblMemberIDReq.setForeground(Color.red);
            
               
         txtMemberID.requestFocus();
     }
     else{
         lblMemberIDReq.setText("");
     }
 }
     private void isInitialsEmpty(){
     if (txtInitials.getText().isBlank()){
           lblInitialsReq.setBounds(458,220,200,25);
         lblInitialsReq.setText("*Initials & surname required!");
          lblInitialsReq.setForeground(Color.red);
          
                
          txtInitials.requestFocus();
     } 
     else {
         lblInitialsReq.setText("");
     }
     }
     private void istxtGradeEmpty(){
     if (txtGrade.getText().isBlank()){
          lblGradeReq.setBounds(458, 260, 200, 25);
         lblGradeReq.setText("*Leaner grade required!");
         lblGradeReq.setForeground(Color.red);
        
         txtGrade.requestFocus();
     }
     else {
         lblGradeReq.setText("");
     }
     
 }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()== btnAddLearner){
          istxtMemberIDEmpty();
          isInitialsEmpty();
          istxtGradeEmpty();
        }
    }
}
