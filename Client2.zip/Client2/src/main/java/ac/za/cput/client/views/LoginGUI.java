/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.views;


import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;


public class LoginGUI implements ActionListener {
 private JFrame frame;
 private JPanel mainPanel, picturePanel, labelPanel;
 
 private JLabel lblUsername, lblPassword, lblPicture, lblLibrain ,lblLogin, lblRequiredUser, lblRequiredPass, lblShowPassword;
 private JTextField txtUsername;
     private JPasswordField   txtPassword;
 private JCheckBox chkShowPass;
 
 private JButton btnLogin, btnCancel;
    
    
    public LoginGUI(){
        frame = new JFrame();
        mainPanel = new JPanel();
        picturePanel =  new JPanel();
        labelPanel =  new JPanel();
        
        lblUsername = new JLabel("Username: ");
        lblPassword = new JLabel("Password: ");
        lblLibrain =  new JLabel("Librarian");
        lblLogin =  new JLabel("Login");
        lblShowPassword =  new JLabel("Show password");
        lblRequiredUser = new JLabel();
        lblRequiredPass =  new JLabel();
        
        txtUsername =  new JTextField();
        txtPassword = new JPasswordField();
        chkShowPass = new JCheckBox();
        chkShowPass.addActionListener(this);
        
       
        btnLogin = new JButton("Login");
        btnLogin.addActionListener(this);
        btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(this);
        
        
    }
    public void setGUI() throws IOException{
        frame.setTitle("Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(440, 340);
        frame.setLocationRelativeTo(null);
        frame.add(mainPanel);
        frame.setResizable(false);
        mainPanel.setLayout(null);
        
        lblLogin.setBounds(150, 5, 80, 30);
        lblLogin.setFont(new Font("SERIF", Font.BOLD, 25));
        mainPanel.add(lblLogin);
        
        picturePanel.setBounds(18,50,100,100);
        BufferedImage image =  ImageIO.read(new File("Librarian.jpg"));
        lblPicture = new JLabel(new ImageIcon(image));
        picturePanel.add( lblPicture);
        mainPanel.add(picturePanel);
        
        labelPanel.setBounds(170, 80, 100,35);
        labelPanel.add( lblLibrain );
        lblLibrain.setForeground(Color.BLUE);
         lblLibrain.setFont(new Font("VERDANA", Font.BOLD, 20));
        mainPanel.add(labelPanel);
        
        lblUsername.setBounds(20, 160, 80, 25);
        mainPanel.add(lblUsername);
        
        lblPassword.setBounds(20, 200, 80, 25);
        mainPanel.add(lblPassword);
        
        txtUsername.setBounds(170, 160, 130, 25);
        txtUsername.setFont(new Font("SERIF", Font.BOLD, 15));
        mainPanel.add(txtUsername);
        
        txtPassword.setBounds(170,200, 130, 25 );
        txtPassword.setFont(new Font("SERIF", Font.BOLD, 15));
        mainPanel.add(txtPassword);
        
        chkShowPass.setBounds(170, 230, 30, 25);
        mainPanel.add(chkShowPass);
        
        lblShowPassword.setBounds(200, 230, 150, 25);
        mainPanel.add(lblShowPassword);
        
        btnLogin.setBounds(20,270, 140, 25 );
        mainPanel.add(btnLogin);
        
        btnCancel.setBounds(160, 270, 140, 25);
        mainPanel.add(btnCancel);
        
         lblRequiredUser.setBounds(301, 160, 130, 25);
         mainPanel.add(lblRequiredUser);
         
         lblRequiredPass.setBounds(301,200,130, 25);
         mainPanel.add(lblRequiredPass);
    
        frame.setVisible(true);

    }

    public void showPassword() {
     if (chkShowPass.isSelected()){
         txtPassword.setEchoChar((char)0);
     }else {
      txtPassword.setEchoChar('*');
     }
    }

    public void istxtUsernameEmpty() {
        if (txtUsername.getText().isBlank()) {
            lblRequiredUser.setText("*Username required");
            lblRequiredUser.setForeground(Color.red);

        } else {
            lblRequiredUser.setText("");
        }
    }

    public void istxtPasswordEmpty() {
        if (txtPassword.getText().isBlank()) {
            lblRequiredPass.setText("*Password required");
            lblRequiredPass.setForeground(Color.red);
        } else {
            lblRequiredPass.setText("");
        }
    }

  
    
    

    @Override
    public void actionPerformed(ActionEvent e) {
       if (e.getSource() == btnLogin){
           istxtUsernameEmpty();
           istxtPasswordEmpty();
           
       
           
          
       }
       
       if (e.getSource()==btnCancel){
           System.exit(0);
       }
       if (e.getSource() == chkShowPass){
            showPassword();
       }
    }

   

    
}
