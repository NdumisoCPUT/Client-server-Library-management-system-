/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.views;


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
public final class AddBook extends JPanel implements ActionListener {
    private JLabel lblPicture, lblIsbnReq, lblBookCategoryReq, lblBookInfo, lblIsbn, lblBookCategory,lblShelfReq, lblShelf,lblAuthorReq, lblAuthor;
    private JTextField txtIsbn, txtBookCategory, txtShelf, txtAuthor;
    private JButton btnAddBook;
   public AddBook() throws IOException 
	{
		super();
		setLayout(null);
		addControls();
              
             
                
                
	}
	
	private void addControls() throws IOException 
	{
		// Set the Labels
                
                BufferedImage image =  ImageIO.read(new File("Add.png"));
                 lblPicture =  new JLabel(new ImageIcon(image));
                
               
                lblBookInfo = new JLabel("Book Information");
                
		lblIsbn = new JLabel("ISBN: ");
                lblIsbnReq  = new JLabel();
                
		lblBookCategory = new JLabel("Book Category: ");
                lblBookCategoryReq =  new JLabel();
                
		lblShelf = new JLabel("Shelf: ");
                lblShelfReq =  new JLabel();
                
                lblAuthor = new JLabel("Author: ");
                lblAuthorReq =  new JLabel();
                
                //bounds
                lblPicture.setBounds(10,20,130,130);
                lblBookInfo.setBounds(200,130,100,25);
		lblIsbn.setBounds(10,180,100,25);
		lblBookCategory.setBounds(10,220,100,25);
		lblShelf.setBounds(10,260,200,25);
                lblAuthor.setBounds(10,300,100,25);
               
                add(lblPicture);
		add(lblIsbn);
                add(lblIsbnReq);
		add(lblBookCategory);
                add(lblBookCategoryReq);
		add(lblShelf);
                add(lblShelfReq);
                add(lblAuthor);
                add(lblAuthorReq);
                add(lblBookInfo);
                
                
		
		//Set the Text Boxes
		txtIsbn = new JTextField();
		txtBookCategory = new JTextField();
		txtShelf = new JTextField();
                txtAuthor = new JTextField();
                
                //bounds
		txtIsbn.setBounds(200,180,200,25);
		txtBookCategory.setBounds(200,220,200,25);
		txtShelf.setBounds(200,260,200,25);
                txtAuthor.setBounds(200,300,200,25);
                
                
		add(txtIsbn);
		add(txtBookCategory);
		add(txtShelf);
                add(txtAuthor);
                
                 btnAddBook = new JButton("Insert the information");
                btnAddBook.setBounds(200, 340, 200, 25);
                btnAddBook.addActionListener(this);
                add(btnAddBook);
                
                //empty
               
	}
        
      private void istxtIsbnEmpty(){
      
          if (txtisbn.getText()){
           lblIsbnReq.setBounds(408,180,200,25);
           lblIsbnReq.setText("*Book ISBN Required!");
           lblIsbnReq.setForeground(Color.red);
           txtIsbn.requestFocus();
         
       } 
       else {
           lblIsbnReq.setText("");
          
       }
      }
      private void isTxtBookCategoryEmpty(){
          if (txtBookCategory.getText().isEmpty()){
              lblBookCategoryReq.setBounds(408,220,200,25);
              lblBookCategoryReq.setText("*Book category required!");
              lblBookCategoryReq.setForeground(Color.red);
              txtBookCategory.requestFocus();

          } else {
              lblBookCategoryReq.setText("");
              
          }
      }
      
      private void isTxtShelfEmpty(){
          
          if (txtShelf.getText().isEmpty()){
              lblShelfReq.setBounds(408,260,200,25);
              lblShelfReq.setText("*Shelf number is required!");
            lblShelfReq.setForeground(Color.red);
            txtShelf.requestFocus();
            
          } else {
              lblShelfReq.setText("");
              
          }
      }
      private void isTxtAuthorEmpty(){
          
          if (txtAuthor.getText().isEmpty()){
              lblAuthorReq.setBounds(408,300,200,25);
              lblAuthorReq.setText("*Book Author required!");
              lblAuthorReq.setForeground(Color.red);
              txtAuthor.requestFocus();
             
          } else {
             lblAuthorReq.setText("");
             
          }
          
          
        
      }
     // private void isTxtIsbnEmpty(){

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnAddBook){
            
          isTxtBookCategoryEmpty();
          isTxtShelfEmpty();
          isTxtAuthorEmpty();
           istxtIsbnEmpty();
           Book  book =  new Book();
         
          
        }
    }
       
       
    }
  
      
      
    
    

        


