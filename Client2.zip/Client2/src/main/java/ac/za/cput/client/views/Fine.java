/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.za.cput.client.views;

/**
 *
 * @author LaSavage
 */
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
public class Fine extends JPanel implements ActionListener {
    
    
    JLabel lblPicture;
   JButton btnFine;
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public Fine() throws IOException  
  {
    // Set Size and Position
setLayout(null);
   
BufferedImage image =  ImageIO.read(new File("Fine.png"));
lblPicture = new JLabel(new ImageIcon(image));
lblPicture.setBounds(270, 20, 150, 95);
add(lblPicture);

    
    // Specify the Column Names in an Array
    String headingColumns[] = 
    {
        "ISBN",
        "Member ID",
        "Issued Date",
        "Period",
        "Fine"
    };
    
    // Data for the Rows of the Table.
  
    String[][] fineData = 
      {
                  {null, null, null, null, null},
                  {null, null, null, null, null},
                  {null, null, null, null, null},
                  {null, null, null, null, null},
                  {null, null, null, null, null},
                  {null, null, null,null, null},
                  {null, null, null, null, null},
                  {null, null, null, null, null},
                  {null, null, null, null, null},
                  {null, null, null, null, null},
                  {null, null, null, null, null},
                  {null, null, null, null, null},};
    
    // Create JTable and add it to Frame
    
  JTable table = new JTable(fineData, headingColumns);


    
    //Show Resize Entire Table, Column shifting, column 
	//Resizing and Cell Editing
    //Shift Click or Click & Drag
    // Apply scrolling support
    JScrollPane scPaneTable = new JScrollPane(table);
    scPaneTable.setBounds(100, 120, 500, 200);
    add(scPaneTable);
    
    btnFine = new JButton("Show Learner & Fine");
    btnFine.setBounds(400,330 , 200, 25);
btnFine.addActionListener(this);
    add(btnFine);
   
  
    
  }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnFine){
            JOptionPane.showMessageDialog(null, "Testing");
        }
    }
  }

