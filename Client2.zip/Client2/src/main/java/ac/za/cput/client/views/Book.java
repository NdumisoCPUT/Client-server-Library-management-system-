
package ac.za.cput.client.views;

import java.io.Serializable;

public class Book implements Serializable{
    
    private int isbn;
    private String bookCategory;
    private int bookShelf;
    private String bookAuthor;

    public int getIsbn() {
        return isbn;
    }

    public String getBookCategory() {
        return bookCategory;
    }

    public int getBookShelf() {
        return bookShelf;
    }

    public String getBookAuthor() {
        return bookAuthor;
      }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public void setBookCategory(String bookCategory) {
        this.bookCategory = bookCategory;
    }

    public void setBookShelf(int bookShelf) {
        this.bookShelf = bookShelf;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }
    
    
    
}
